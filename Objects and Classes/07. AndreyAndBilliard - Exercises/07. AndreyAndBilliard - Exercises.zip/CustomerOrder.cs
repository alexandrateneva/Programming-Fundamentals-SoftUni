﻿

namespace _07.AndreyAndBilliard___Exercises
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class CustomerOrder
    {
        public string Name { get; set; }

        public string KindOfProduct { get; set; }

        public int Quantity { get; set; }

        public decimal Price { get; set; }

        public decimal Bill { get; set; }


    }
}
