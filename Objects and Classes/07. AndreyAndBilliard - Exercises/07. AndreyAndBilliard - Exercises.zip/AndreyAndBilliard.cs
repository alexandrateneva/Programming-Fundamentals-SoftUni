﻿

namespace _07.AndreyAndBilliard___Exercises
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class AndreyAndBilliard
    {
        public static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            var productPrice = new Dictionary<string, decimal>();
            var orderOfPerson = new Dictionary<string, CustomerOrder>();

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split('-');
                productPrice[input[0]] = decimal.Parse(input[1]);
            }

            while (true)
            {
                var input2 = Console.ReadLine();
                if (input2 != "end of clients")
                {
                    var customerNameAndOrder = input2.Split('-');
                    var currentOrder = new CustomerOrder();
                    currentOrder.Name = customerNameAndOrder[0];
                    var customerOrder = customerNameAndOrder[1].Split(',');
                    currentOrder.KindOfProduct = customerOrder[0];
                    currentOrder.Quantity = int.Parse(customerOrder[1]);
                    decimal bill = 0;
                    if (productPrice.ContainsKey(currentOrder.KindOfProduct))
                    {
                        bill = currentOrder.Quantity * productPrice[currentOrder.KindOfProduct];
                    }
                    if (orderOfPerson.ContainsKey(currentOrder.Name))
                    {
                        currentOrder.Bill += bill;
                        orderOfPerson[currentOrder.Name] = currentOrder;
                    }
                    else
                    {
                        currentOrder.Bill = bill;
                        orderOfPerson[currentOrder.Name] = currentOrder;
                    }
                }
                else
                {
                    foreach (var item in orderOfPerson)
                    {
                        if (item.Value.Bill > 0)
                        {
                            Console.WriteLine($"{item.Key}");
                            Console.WriteLine($"-- {item.Value.KindOfProduct} - {item.Value.Quantity}");
                            Console.WriteLine($"Bill: {item.Value.Bill:F2}");
                       }                        
                    }
                }                
            }
        }
    }
}
